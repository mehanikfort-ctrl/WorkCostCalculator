# Сборка APK с телефона

Этот проект подготовлен для сборки APK через GitHub Actions.

## Вариант без установки Android Studio
1. Создайте репозиторий на GitHub.
2. Загрузите в него содержимое этой папки.
3. Откройте вкладку **Actions**.
4. Выберите **Build APK**.
5. Нажмите **Run workflow**.
6. После завершения откройте выполненный workflow и скачайте artifact **WorkCostCalculator-v1.4-debug**.
7. Внутри будет `app-debug.apk`.

Workflow собирает debug APK на сервере GitHub Actions. Для публикации в Google Play нужен отдельный подписанный release/AAB build.
