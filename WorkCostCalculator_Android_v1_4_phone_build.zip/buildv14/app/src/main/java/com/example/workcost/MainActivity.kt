package com.example.workcost

import android.os.Bundle
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.material3.adaptive.navigationsuite.NavigationSuiteScaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}

fun vars(expr:String)=listOf("Q","L","W","H","P").filter{Regex("\\b$it\\b").containsMatchIn(expr)}
fun encodeInputs(m:Map<String,Double>)=m.entries.joinToString(";"){"${it.key}=${it.value}"}
fun decodeInputs(s:String):MutableMap<String,Double>{val m=mutableMapOf<String,Double>();s.split(";").forEach{p->val a=p.split("=");if(a.size==2)m[a[0]]=a[1].toDoubleOrNull()?:0.0};return m}
fun calc(expr:String,values:Map<String,Double>):Double=try{MathParser.eval(expr.replace("×","*").replace("÷","/").replace("−","-"),values)}catch(_:Exception){0.0}
object MathParser{
 fun eval(input:String,values:Map<String,Double>):Double{
  var t=input.replace(" ","")
  for((k,n) in values)t=t.replace(Regex("\\b$k\\b"),n.toString())
  var i=0
  fun expr():Double{var x=term();while(i<t.length&&(t[i]=='+'||t[i]=='-')){val o=t[i++];val y=term();x=if(o=='+')x+y else x-y};return x}
  fun term():Double{var x=factor();while(i<t.length&&(t[i]=='*'||t[i]=='/')){val o=t[i++];val y=factor();x=if(o=='*')x*y else x/y};return x}
  fun factor():Double{
   if(i<t.length&&t[i]=='('){i++;val x=expr();if(i>=t.length||t[i]!=')')throw IllegalArgumentException();i++;return x}
   val st=i;if(i<t.length&&(t[i]=='+'||t[i]=='-'))i++;while(i<t.length&&(t[i].isDigit()||t[i]=='.'))i++
   if(st==i)throw IllegalArgumentException();return t.substring(st,i).toDouble()
  }
  val result=expr();if(i!=t.length)throw IllegalArgumentException();return result
 }
}

@Composable fun App(){
 val context=LocalContext.current;val dao=remember{AppDatabase.get(context).dao()};val scope=rememberCoroutineScope()
 val sections by dao.sections().collectAsState(emptyList());val categories by dao.categories().collectAsState(emptyList());val units by dao.units().collectAsState(emptyList());val formulas by dao.formulas().collectAsState(emptyList());val works by dao.works().collectAsState(emptyList());val estimates by dao.estimates().collectAsState(emptyList())
 var tab by remember{mutableIntStateOf(0)};var calcWork by remember{mutableStateOf<WorkEntity?>(null)};var openEstimate by remember{mutableStateOf<Long?>(null)}
 LaunchedEffect(Unit){if(dao.sectionCount()==0)dao.addSections(listOf("Строительные","Земляные","Кровельные","Электрика","Лазерная резка").mapIndexed{i,n->SectionEntity(name=n,sortOrder=i)});if(dao.unitCount()==0)dao.addUnits(listOf("шт.","м","пог.м","м²","м³","см²").map{UnitEntity(name=it)});if(dao.formulaCount()==0)dao.addFormulas(listOf(FormulaEntity(name="Количество",expression="Q"),FormulaEntity(name="Длина",expression="L"),FormulaEntity(name="Площадь",expression="L × W"),FormulaEntity(name="Объём",expression="L × W × H"),FormulaEntity(name="Количество × цена",expression="Q × P")))}
 if(openEstimate!=null){EstimateDetail(openEstimate!!,dao,works,units,formulas){openEstimate=null};return}
 if(calcWork!=null){val w=calcWork!!;val f=formulas.find{it.id==w.formulaId};val u=units.find{it.id==w.unitId};if(f!=null&&u!=null)CalculationScreen(w,f,u){calcWork=null};return}
 NavigationSuiteScaffold(navigationSuiteItems={listOf("Работы","База цен","Моя смета","Настройки").forEachIndexed{i,n->item(tab==i,{tab=i},{Text(listOf("⌂","▣","▤","⚙")[i])},{Text(n)})}}){when(tab){0->WorksScreen(works,sections,categories,units,formulas){calcWork=it};1->MarketScreen(works,units);2->EstimatesScreen(estimates,dao){openEstimate=it};3->SettingsScreen(dao,sections,categories,units,formulas,works)}}
}

@Composable fun Header(t:String,s:String?=null){Column(Modifier.padding(20.dp)){Text(t,style=MaterialTheme.typography.headlineMedium);if(s!=null)Text(s,color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable fun WorksScreen(ws:List<WorkEntity>,ss:List<SectionEntity>,cs:List<CategoryEntity>,us:List<UnitEntity>,fs:List<FormulaEntity>,open:(WorkEntity)->Unit){var q by remember{mutableStateOf("")};var sid by remember{mutableLongStateOf(0)};Column{Header("Работы","Выберите работу для расчёта");OutlinedTextField(q,{q=it},Modifier.fillMaxWidth().padding(horizontal=16.dp),label={Text("Поиск")},singleLine=true);LazyRow(Modifier.padding(12.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){item{FilterChip(sid==0,{sid=0},{Text("Все")})};items(ss){s->FilterChip(sid==s.id,{sid=s.id},{Text(s.name)})}};LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items(ws.filter{(sid==0||it.sectionId==sid)&&(q.isBlank()||it.name.contains(q,true))}){w->ElevatedCard(onClick={open(w)},Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(w.name,style=MaterialTheme.typography.titleMedium);Text("${ss.find{it.id==w.sectionId}?.name.orEmpty()} • ${cs.find{it.id==w.categoryId}?.name.orEmpty()}");Text("${w.price} ₽ / ${us.find{it.id==w.unitId}?.name.orEmpty()}");Text("${fs.find{it.id==w.formulaId}?.expression.orEmpty()}",color=MaterialTheme.colorScheme.onSurfaceVariant)}}}}}}
@Composable fun MarketScreen(ws:List<WorkEntity>,us:List<UnitEntity>){Column{Header("База цен","Рынок и ваша цена");LazyColumn(contentPadding=PaddingValues(16.dp)){items(ws){w->Card(Modifier.fillMaxWidth().padding(bottom=8.dp)){Column(Modifier.padding(15.dp)){Text(w.name,style=MaterialTheme.typography.titleMedium);Text("Рынок: ${w.min}–${w.max} ₽ / ${us.find{it.id==w.unitId}?.name.orEmpty()}");Text("Ваша цена: ${w.price} ₽",color=MaterialTheme.colorScheme.primary);if(w.source.isNotBlank())Text("Источник: ${w.source} ${w.sourceDate}")}}}}}}

@Composable fun EstimatesScreen(es:List<EstimateEntity>,dao:AppDao,open:(Long)->Unit){var add by remember{mutableStateOf(false)};val scope=rememberCoroutineScope();Column{Header("Моя смета","Сохраняйте объекты и их расчёты");Button({add=true},Modifier.fillMaxWidth().padding(horizontal=16.dp)){Text("＋ Создать объект")};if(es.isEmpty())Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text("Пока нет объектов")};LazyColumn(contentPadding=PaddingValues(16.dp)){items(es){e->ElevatedCard(onClick={open(e.id)},Modifier.fillMaxWidth().padding(bottom=10.dp)){Column(Modifier.padding(16.dp)){Text(e.name,style=MaterialTheme.typography.titleLarge);if(e.customer.isNotBlank())Text(e.customer);if(e.note.isNotBlank())Text(e.note,color=MaterialTheme.colorScheme.onSurfaceVariant);TextButton({scope.launch(Dispatchers.IO){dao.deleteEstimate(e)}}){Text("Удалить")}}}}}};if(add)EstimateDialog({n,c,note->scope.launch(Dispatchers.IO){dao.addEstimate(EstimateEntity(name=n,customer=c,note=note));add=false}},{add=false})}}
@Composable fun EstimateDialog(save:(String,String,String)->Unit,close:()->Unit){var n by remember{mutableStateOf("")};var c by remember{mutableStateOf("")};var note by remember{mutableStateOf("")};AlertDialog(onDismissRequest=close,title={Text("Новый объект")},text={Column{OutlinedTextField(n,{n=it},label={Text("Название объекта")});OutlinedTextField(c,{c=it},label={Text("Заказчик")});OutlinedTextField(note,{note=it},label={Text("Примечание")})}},confirmButton={Button({if(n.isNotBlank())save(n,c,note)}){Text("Создать")}},dismissButton={TextButton(close){Text("Отмена")}})}


fun createEstimatePdf(context: android.content.Context, uri: Uri, estimate: EstimateEntity?, items: List<EstimateItemEntity>) {
    val pdf=PdfDocument()
    var pageNo=1
    var page=pdf.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create())
    var canvas=page.canvas
    val paint=Paint().apply{color=android.graphics.Color.BLACK}
    fun header(){
        paint.textSize=20f; canvas.drawText("СМЕТА",40f,45f,paint)
        paint.textSize=12f; canvas.drawText(estimate?.name.orEmpty(),40f,68f,paint)
        if(!estimate?.customer.isNullOrBlank()) canvas.drawText("Заказчик: ${estimate?.customer}",40f,86f,paint)
        paint.textSize=11f
        canvas.drawText("№",35f,115f,paint); canvas.drawText("Наименование",60f,115f,paint)
        canvas.drawText("Ед.",330f,115f,paint); canvas.drawText("Цена",380f,115f,paint); canvas.drawText("Сумма",465f,115f,paint)
    }
    header(); var y=138f
    items.forEachIndexed{idx,it->
        if(y>780f){pdf.finishPage(page);pageNo++;page=pdf.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create());canvas=page.canvas;header();y=138f}
        paint.textSize=10f
        val name=if(it.itemType=="MATERIAL")"[Материал] ${it.workName}" else it.workName
        canvas.drawText("${idx+1}",35f,y,paint)
        canvas.drawText(name.take(42),60f,y,paint)
        canvas.drawText(it.unitName.take(8),330f,y,paint)
        canvas.drawText("%.2f".format(it.price),380f,y,paint)
        canvas.drawText("%.2f".format(it.total),465f,y,paint)
        y+=21f
    }
    val work=items.filter{it.itemType=="WORK"}.sumOf{it.total}; val mat=items.filter{it.itemType=="MATERIAL"}.sumOf{it.total}; val total=work+mat
    if(y>735f){pdf.finishPage(page);pageNo++;page=pdf.startPage(PdfDocument.PageInfo.Builder(595,842,pageNo).create());canvas=page.canvas;y=70f}
    paint.textSize=12f;canvas.drawText("Работа: %.2f ₽".format(work),350f,y,paint);y+=20
    canvas.drawText("Материалы: %.2f ₽".format(mat),350f,y,paint);y+=24
    paint.textSize=16f;canvas.drawText("ИТОГО: %.2f ₽".format(total),350f,y,paint)
    pdf.finishPage(page)
    context.contentResolver.openOutputStream(uri)?.use{pdf.writeTo(it)}
    pdf.close()
}

@Composable fun EstimateDetail(id:Long,dao:AppDao,works:List<WorkEntity>,units:List<UnitEntity>,formulas:List<FormulaEntity>,back:()->Unit){
 val es by dao.estimates().collectAsState(emptyList()); val e=es.find{it.id==id}; val items by dao.estimateItems(id).collectAsState(emptyList()); val scope=rememberCoroutineScope(); var add by remember{mutableStateOf(false)}; var edit by remember{mutableStateOf<EstimateItemEntity?>(null)}
 val context=LocalContext.current
 val launcher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")){uri->if(uri!=null)createEstimatePdf(context,uri,e,items)}
 val workTotal=items.filter{it.itemType=="WORK"}.sumOf{it.total}; val matTotal=items.filter{it.itemType=="MATERIAL"}.sumOf{it.total}; val total=workTotal+matTotal
 Column{Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){TextButton(back){Text("‹ Назад")};Column(Modifier.weight(1f)){Text(e?.name.orEmpty(),style=MaterialTheme.typography.titleLarge);Text(e?.customer.orEmpty(),color=MaterialTheme.colorScheme.onSurfaceVariant)}}
 Row(Modifier.fillMaxWidth().padding(horizontal=16.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({add=true},Modifier.weight(1f)){Text("＋ Добавить")};OutlinedButton({launcher.launch("Сmeta_${e?.name.orEmpty()}.pdf")},Modifier.weight(1f)){Text("PDF")}}
 LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(items){it->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(if(it.itemType=="MATERIAL")"Материал • ${it.workName}" else it.workName,style=MaterialTheme.typography.titleMedium);Text("${it.formulaExpression} • ${it.price} ₽ / ${it.unitName}",color=MaterialTheme.colorScheme.onSurfaceVariant);Text("${"%.2f".format(it.total)} ₽",style=MaterialTheme.typography.titleLarge);Row{TextButton({edit=it}){Text("Изменить")};TextButton({scope.launch(Dispatchers.IO){dao.deleteEstimateItem(it)}}){Text("Удалить")}}}}};item{ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("РАБОТА: ${"%.2f".format(workTotal)} ₽");Text("МАТЕРИАЛЫ: ${"%.2f".format(matTotal)} ₽");HorizontalDivider(Modifier.padding(vertical=8.dp));Text("ИТОГО: ${"%.2f".format(total)} ₽",style=MaterialTheme.typography.headlineMedium)}}}}
 }
 if(add)AddEstimateItemDialog(works,units,formulas,{type,w,f,u,name,qty,price->scope.launch(Dispatchers.IO){if(type=="MATERIAL"){val total=qty*price;dao.addEstimateItem(EstimateItemEntity(estimateId=id,workId=null,workName=name,unitName="шт.",formulaExpression="Q × P",price=price,inputs=encodeInputs(mapOf("Q" to qty,"P" to price)),total=total,sortOrder=items.size,itemType="MATERIAL"))}else{val m=mutableMapOf<String,Double>();vars(f!!.expression).forEach{m[it]=if(it=="P")w!!.price else 1.0};dao.addEstimateItem(EstimateItemEntity(estimateId=id,workId=w!!.id,workName=w.name,unitName=u!!.name,formulaExpression=f.expression,price=w.price,inputs=encodeInputs(m),total=calc(f.expression,m),sortOrder=items.size,itemType="WORK"))};add=false}},{add=false})
 if(edit!=null)EstimateItemEditor(edit!!,{new->scope.launch(Dispatchers.IO){dao.updateEstimateItem(new.copy(total=calc(new.formulaExpression,decodeInputs(new.inputs))))};edit=null},{edit=null})
}

@Composable fun AddEstimateItemDialog(ws:List<WorkEntity>,us:List<UnitEntity>,fs:List<FormulaEntity>,add:(String,WorkEntity?,FormulaEntity?,UnitEntity?,String,Double,Double)->Unit,close:()->Unit){
 var material by remember{mutableStateOf(false)};var w by remember{mutableStateOf<WorkEntity?>(null)};var f by remember{mutableStateOf<FormulaEntity?>(null)};var u by remember{mutableStateOf<UnitEntity?>(null)};var mn by remember{mutableStateOf("")};var mq by remember{mutableStateOf("1")};var mp by remember{mutableStateOf("0")}
 if(material){AlertDialog(onDismissRequest=close,title={Text("Добавить материал")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(mn,{mn=it},label={Text("Наименование")});OutlinedTextField(mq,{mq=it},label={Text("Количество")});OutlinedTextField(mp,{mp=it},label={Text("Цена за единицу")});Text("Сумма: %.2f ₽".format((mq.replace(',','.').toDoubleOrNull()?:0.0)*(mp.replace(',','.').toDoubleOrNull()?:0.0))) }},confirmButton={Button({if(mn.isNotBlank())add("MATERIAL",null,null,null,mn,mq.replace(',','.').toDoubleOrNull()?:0.0,mp.replace(',','.').toDoubleOrNull()?:0.0)}){Text("Добавить")}},dismissButton={TextButton(close){Text("Отмена")}})} else {AlertDialog(onDismissRequest=close,title={Text("Добавить позицию")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Button({material=true},Modifier.fillMaxWidth()){Text("＋ Материал")};Text("Или выберите работу",style=MaterialTheme.typography.labelLarge);LazyColumn(Modifier.heightIn(max=300.dp)){items(ws){x->FilterChip(w?.id==x.id,{w=x},{Text(x.name)})}};if(w!=null){f=fs.find{it.id==w!!.formulaId};u=us.find{it.id==w!!.unitId};Text("Формула: ${f?.expression.orEmpty()}")}}},confirmButton={Button({if(w!=null&&f!=null&&u!=null)add("WORK",w,f,u,w!!.name,1.0,w!!.price)}){Text("Добавить работу")}},dismissButton={TextButton(close){Text("Отмена")}})}}

@Composable fun EstimateItemEditor(item:EstimateItemEntity,save:(EstimateItemEntity)->Unit,close:()->Unit){var inputs=remember{mutableStateOf(decodeInputs(item.inputs))};val vs=vars(item.formulaExpression);AlertDialog(onDismissRequest=close,title={Text(item.workName)},text={Column{vs.forEach{v->OutlinedTextField((inputs.value[v]?:0.0).toString(),{inputs.value[v]=it.replace(',','.').toDoubleOrNull()?:0.0},label={Text(label(v))})};Text("Итого: ${"%.2f".format(calc(item.formulaExpression,inputs.value))} ₽")}},confirmButton={Button({save(item.copy(inputs=encodeInputs(inputs.value),total=calc(item.formulaExpression,inputs.value)))}){Text("Сохранить")}},dismissButton={TextButton(close){Text("Отмена")}})}
fun label(v:String)=when(v){"Q"->"Количество";"L"->"Длина, м";"W"->"Ширина, м";"H"->"Высота / глубина, м";"P"->"Цена, ₽";else->v}

@Composable fun CalculationScreen(work:WorkEntity,formula:FormulaEntity,unit:UnitEntity,back:()->Unit){val values=remember{mutableStateMapOf<String,Double>()};val vs=vars(formula.expression);vs.forEach{if(!values.containsKey(it))values[it]=if(it=="P")work.price else 1.0};Column{Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){TextButton(back){Text("‹ Назад")};Column{Text(work.name,style=MaterialTheme.typography.titleLarge);Text(formula.expression,color=MaterialTheme.colorScheme.onSurfaceVariant)}};LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items(vs){v->OutlinedTextField(values[v].toString(),{values[v]=it.replace(',','.').toDoubleOrNull()?:0.0},Modifier.fillMaxWidth(),label={Text(label(v))})};item{ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(20.dp)){Text("ИТОГО");Text("${"%.2f".format(calc(formula.expression,values))} ₽",style=MaterialTheme.typography.headlineLarge)}}}}}}

@Composable fun SettingsScreen(dao:AppDao,ss:List<SectionEntity>,cs:List<CategoryEntity>,us:List<UnitEntity>,fs:List<FormulaEntity>,ws:List<WorkEntity>){var screen by remember{mutableStateOf("Разделы")};var sec by remember{mutableStateOf<SectionEntity?>(null)};var cat by remember{mutableStateOf<CategoryEntity?>(null)};var unit by remember{mutableStateOf<UnitEntity?>(null)};var form by remember{mutableStateOf<FormulaEntity?>(null)};val scope=rememberCoroutineScope();Column{Header("Настройки","Управление справочниками и работами");LazyRow(Modifier.padding(12.dp),horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("Разделы","Категории","Формулы","Единицы","Работы").forEach{s->item{FilterChip(screen==s,{screen=s},{Text(s)})}}};when(screen){"Разделы"->ManagerList(ss.map{it.id to it.name},"Добавить раздел",{n->scope.launch{dao.addSection(SectionEntity(name=n))}}){id->sec=ss.find{it.id==id}};"Категории"->CategorySettings(ss,cs,dao);"Формулы"->ManagerList(fs.map{it.id to "${it.name}: ${it.expression}"},"Создать формулу",{n->scope.launch{dao.addFormula(FormulaEntity(name=n,expression="Q"))}}){id->form=fs.find{it.id==id}};"Единицы"->ManagerList(us.map{it.id to it.name},"Добавить единицу",{n->scope.launch{dao.addUnit(UnitEntity(name=n))}}){id->unit=us.find{it.id==id}};"Работы"->WorkSettings(ws,ss,cs,us,fs,dao)}};if(sec!=null)EditName(sec!!.name,{n->scope.launch{dao.updateSection(sec!!.copy(name=n));sec=null}});if(unit!=null)EditName(unit!!.name,{n->scope.launch{dao.updateUnit(unit!!.copy(name=n));unit=null}});if(form!=null)EditFormula(form!!,dao){form=null}}
@Composable fun ManagerList(data:List<Pair<Long,String>>,button:String,add:(String)->Unit,edit:(Long)->Unit){var new by remember{mutableStateOf(false)};Column(Modifier.padding(16.dp)){Button({new=true},Modifier.fillMaxWidth()){Text("＋ $button")};LazyColumn{items(data){x->ListItem(headlineContent={Text(x.second)},trailingContent={TextButton({edit(x.first)}){Text("Изменить")}})}}};if(new)SimpleInput(button,{add(it);new=false})}
@Composable fun CategorySettings(ss:List<SectionEntity>,cs:List<CategoryEntity>,dao:AppDao){val scope=rememberCoroutineScope();var sid by remember{mutableLongStateOf(ss.firstOrNull()?.id?:0)};var new by remember{mutableStateOf(false)};Column(Modifier.padding(16.dp)){LazyRow{items(ss){s->FilterChip(sid==s.id,{sid=s.id},{Text(s.name)})}};Button({new=true},Modifier.fillMaxWidth()){Text("＋ Добавить категорию")};LazyColumn{items(cs.filter{it.sectionId==sid}){c->ListItem(headlineContent={Text(c.name)},trailingContent={TextButton({scope.launch{dao.updateCategory(c.copy(name=c.name))}}){Text("Готово")}})}}};if(new)SimpleInput("Новая категория"){n->scope.launch{dao.addCategory(CategoryEntity(sectionId=sid,name=n))};new=false}}
@Composable fun WorkSettings(ws:List<WorkEntity>,ss:List<SectionEntity>,cs:List<CategoryEntity>,us:List<UnitEntity>,fs:List<FormulaEntity>,dao:AppDao){val scope=rememberCoroutineScope();var edit by remember{mutableStateOf<WorkEntity?>(null)};Column(Modifier.padding(16.dp)){LazyColumn{items(ws){w->ListItem(headlineContent={Text(w.name)},supportingContent={Text("${w.price} ₽")},trailingContent={Row{TextButton({edit=w}){Text("Изменить")};TextButton({scope.launch{dao.deleteWork(w)}}){Text("Удалить")}}})}}};if(edit!=null)WorkEditor(edit!!,ss,cs,us,fs,dao){edit=null}}
@Composable fun WorkEditor(w:WorkEntity,ss:List<SectionEntity>,cs:List<CategoryEntity>,us:List<UnitEntity>,fs:List<FormulaEntity>,dao:AppDao,close:()->Unit){val scope=rememberCoroutineScope();var n by remember{mutableStateOf(w.name)};var p by remember{mutableStateOf(w.price.toString())};var sid by remember{mutableLongStateOf(w.sectionId)};var cid by remember{mutableLongStateOf(w.categoryId)};var uid by remember{mutableLongStateOf(w.unitId)};var fid by remember{mutableLongStateOf(w.formulaId)};AlertDialog(onDismissRequest=close,title={Text("Работа")},text={LazyColumn{item{OutlinedTextField(n,{n=it},label={Text("Название")})};item{OutlinedTextField(p,{p=it},label={Text("Цена")})};item{Text("Раздел")};item{LazyRow{items(ss){s->FilterChip(sid==s.id,{sid=s.id;cid=cs.find{it.sectionId==s.id}?.id?:0},{Text(s.name)})}}};item{Text("Категория")};item{LazyRow{items(cs.filter{it.sectionId==sid}){c->FilterChip(cid==c.id,{cid=c.id},{Text(c.name)})}}};item{Text("Единица")};item{LazyRow{items(us){u->FilterChip(uid==u.id,{uid=u.id},{Text(u.name)})}}};item{Text("Формула")};item{LazyRow{items(fs){f->FilterChip(fid==f.id,{fid=f.id},{Text(f.name)})}}}}},confirmButton={Button({scope.launch{dao.updateWork(w.copy(name=n,price=p.replace(',','.').toDoubleOrNull()?:0.0,sectionId=sid,categoryId=cid,unitId=uid,formulaId=fid));close()}}){Text("Сохранить")}},dismissButton={TextButton(close){Text("Отмена")}})}
@Composable fun SimpleInput(title:String,save:(String)->Unit){var x by remember{mutableStateOf("")};AlertDialog(onDismissRequest={},title={Text(title)},text={OutlinedTextField(x,{x=it},label={Text("Название")})},confirmButton={Button({if(x.isNotBlank())save(x)}){Text("Сохранить")}})}
@Composable fun EditName(initial:String,save:(String)->Unit){SimpleInput("Изменить",save)}
@Composable fun EditFormula(f:FormulaEntity,dao:AppDao,close:()->Unit){val scope=rememberCoroutineScope();var n by remember{mutableStateOf(f.name)};var e by remember{mutableStateOf(f.expression)};AlertDialog(onDismissRequest=close,title={Text("Формула")},text={Column{OutlinedTextField(n,{n=it},label={Text("Название")});OutlinedTextField(e,{e=it},label={Text("Формула: Q L W H P")})}},confirmButton={Button({scope.launch{dao.updateFormula(f.copy(name=n,expression=e));close()}}){Text("Сохранить")}},dismissButton={TextButton(close){Text("Отмена")}})}
