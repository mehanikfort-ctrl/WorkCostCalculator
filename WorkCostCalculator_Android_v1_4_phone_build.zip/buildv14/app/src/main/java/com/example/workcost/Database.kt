package com.example.workcost

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName="sections")
data class SectionEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val sortOrder:Int=0)
@Entity(tableName="categories",foreignKeys=[ForeignKey(entity=SectionEntity::class,parentColumns=["id"],childColumns=["sectionId"],onDelete=ForeignKey.CASCADE)],indices=[Index("sectionId")])
data class CategoryEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val sectionId:Long,val name:String,val sortOrder:Int=0)
@Entity(tableName="units") data class UnitEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String)
@Entity(tableName="formulas") data class FormulaEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val expression:String,val sortOrder:Int=0)
@Entity(tableName="works",foreignKeys=[
 ForeignKey(entity=SectionEntity::class,parentColumns=["id"],childColumns=["sectionId"],onDelete=ForeignKey.RESTRICT),
 ForeignKey(entity=CategoryEntity::class,parentColumns=["id"],childColumns=["categoryId"],onDelete=ForeignKey.RESTRICT),
 ForeignKey(entity=UnitEntity::class,parentColumns=["id"],childColumns=["unitId"],onDelete=ForeignKey.RESTRICT),
 ForeignKey(entity=FormulaEntity::class,parentColumns=["id"],childColumns=["formulaId"],onDelete=ForeignKey.RESTRICT)
],indices=[Index("sectionId"),Index("categoryId"),Index("unitId"),Index("formulaId")])
data class WorkEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val sectionId:Long,val categoryId:Long,val unitId:Long,val formulaId:Long,val name:String,val price:Double,val min:Double,val max:Double,val source:String="",val sourceDate:String="")

@Entity(tableName="estimates") data class EstimateEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val name:String,val customer:String="",val note:String="",val createdAt:Long=System.currentTimeMillis(),val updatedAt:Long=System.currentTimeMillis())
@Entity(tableName="estimate_items",foreignKeys=[ForeignKey(entity=EstimateEntity::class,parentColumns=["id"],childColumns=["estimateId"],onDelete=ForeignKey.CASCADE),ForeignKey(entity=WorkEntity::class,parentColumns=["id"],childColumns=["workId"],onDelete=ForeignKey.RESTRICT)],indices=[Index("estimateId"),Index("workId")])
data class EstimateItemEntity(@PrimaryKey(autoGenerate=true) val id:Long=0,val estimateId:Long,val workId:Long?,val workName:String,val unitName:String,val formulaExpression:String,val price:Double,val inputs:String="Q=1",val total:Double=0.0,val sortOrder:Int=0,val itemType:String="WORK")

@Dao interface AppDao{
 @Query("SELECT * FROM sections ORDER BY sortOrder,name") fun sections():Flow<List<SectionEntity>>
 @Query("SELECT * FROM categories ORDER BY sectionId,sortOrder,name") fun categories():Flow<List<CategoryEntity>>
 @Query("SELECT * FROM categories WHERE sectionId=:sectionId ORDER BY sortOrder,name") fun categoriesOf(sectionId:Long):Flow<List<CategoryEntity>>
 @Query("SELECT * FROM units ORDER BY name") fun units():Flow<List<UnitEntity>>
 @Query("SELECT * FROM formulas ORDER BY sortOrder,name") fun formulas():Flow<List<FormulaEntity>>
 @Query("SELECT * FROM works ORDER BY name") fun works():Flow<List<WorkEntity>>
 @Query("SELECT * FROM estimates ORDER BY updatedAt DESC") fun estimates():Flow<List<EstimateEntity>>
 @Query("SELECT * FROM estimate_items WHERE estimateId=:estimateId ORDER BY sortOrder,id") fun estimateItems(estimateId:Long):Flow<List<EstimateItemEntity>>
 @Insert suspend fun addSection(x:SectionEntity):Long
 @Update suspend fun updateSection(x:SectionEntity)
 @Delete suspend fun deleteSection(x:SectionEntity)
 @Insert suspend fun addCategory(x:CategoryEntity):Long
 @Update suspend fun updateCategory(x:CategoryEntity)
 @Delete suspend fun deleteCategory(x:CategoryEntity)
 @Insert suspend fun addUnit(x:UnitEntity):Long
 @Update suspend fun updateUnit(x:UnitEntity)
 @Delete suspend fun deleteUnit(x:UnitEntity)
 @Insert suspend fun addFormula(x:FormulaEntity):Long
 @Update suspend fun updateFormula(x:FormulaEntity)
 @Delete suspend fun deleteFormula(x:FormulaEntity)
 @Insert suspend fun addWork(x:WorkEntity):Long
 @Update suspend fun updateWork(x:WorkEntity)
 @Delete suspend fun deleteWork(x:WorkEntity)
 @Insert suspend fun addEstimate(x:EstimateEntity):Long
 @Update suspend fun updateEstimate(x:EstimateEntity)
 @Delete suspend fun deleteEstimate(x:EstimateEntity)
 @Insert suspend fun addEstimateItem(x:EstimateItemEntity):Long
 @Update suspend fun updateEstimateItem(x:EstimateItemEntity)
 @Delete suspend fun deleteEstimateItem(x:EstimateItemEntity)
 @Query("DELETE FROM estimate_items WHERE estimateId=:estimateId") suspend fun deleteEstimateItems(estimateId:Long)
 @Query("SELECT COUNT(*) FROM sections") suspend fun sectionCount():Int
 @Query("SELECT COUNT(*) FROM units") suspend fun unitCount():Int
 @Query("SELECT COUNT(*) FROM formulas") suspend fun formulaCount():Int
 @Insert suspend fun addSections(x:List<SectionEntity>)
 @Insert suspend fun addUnits(x:List<UnitEntity>)
 @Insert suspend fun addFormulas(x:List<FormulaEntity>)
}

@Database(entities=[SectionEntity::class,CategoryEntity::class,UnitEntity::class,FormulaEntity::class,WorkEntity::class,EstimateEntity::class,EstimateItemEntity::class],version=5,exportSchema=false)
abstract class AppDatabase:RoomDatabase(){
 abstract fun dao():AppDao
 companion object{ @Volatile private var INSTANCE:AppDatabase?=null
  fun get(context:Context)=INSTANCE?:synchronized(this){INSTANCE?:Room.databaseBuilder(context.applicationContext,AppDatabase::class.java,"work_cost.db").fallbackToDestructiveMigration().build().also{INSTANCE=it}}
 }
}
